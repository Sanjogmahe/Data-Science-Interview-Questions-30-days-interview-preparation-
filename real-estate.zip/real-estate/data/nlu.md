## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there
- Get Started

## intent:buy_a_home
- Buy A Home
- buy a home
- buy home
- Buy Home

## intent:sell_your_home
- Sell Your Home
- sell your home
- SELL YOUR HOME
- sell home
- Sell Home

## intent:goodbye
- bye
- goodbye
- see you around
- see you later



